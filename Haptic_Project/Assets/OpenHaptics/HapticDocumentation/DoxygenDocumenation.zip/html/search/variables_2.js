var searchData=
[
  ['device_5fmodel',['device_Model',['../class_haptic_plugin.html#a1e6fa14010dfdabb1fb497e26229e2d6',1,'HapticPlugin']]],
  ['device_5fserialnumber',['device_SerialNumber',['../class_haptic_plugin.html#ad1bde4c6da74b2edcf745a87e3285065',1,'HapticPlugin']]],
  ['direction',['Direction',['../class_haptic_effect.html#a29924a3f37b545cc2fc268916399d635',1,'HapticEffect']]]
];
