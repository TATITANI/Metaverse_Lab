var searchData=
[
  ['friction',['FRICTION',['../class_haptic_effect.html#a1564d4c9b76b33b1fa6cba145ff2165dacf288405946b7650ed4276980cdaad0c',1,'HapticEffect']]]
];
