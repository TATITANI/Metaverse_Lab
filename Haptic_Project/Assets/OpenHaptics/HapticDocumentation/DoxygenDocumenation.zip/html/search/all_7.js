var searchData=
[
  ['initdevice',['initDevice',['../class_haptic_plugin.html#ac7ad00ab4b4a97673c990b01942b987d',1,'HapticPlugin']]],
  ['inkwell',['inkwell',['../class_haptic_plugin.html#add88c6dd69ad4e56af4d81297dc7ad78',1,'HapticPlugin']]],
  ['isgrabbing',['isGrabbing',['../class_haptic_grabber.html#a5b37ed3e605a185dba2143075461751e',1,'HapticGrabber']]]
];
