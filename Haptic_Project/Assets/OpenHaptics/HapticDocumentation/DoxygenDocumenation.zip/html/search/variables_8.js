var searchData=
[
  ['magnitude',['Magnitude',['../class_haptic_effect.html#abcc3364085b0fecd8ffe6bd9f574e794',1,'HapticEffect']]],
  ['margin',['margin',['../class_haptic_fit_to_camera.html#adefbab9d738ca4b566072516bbe28fda',1,'HapticFitToCamera']]],
  ['mastercamera',['masterCamera',['../class_haptic_fit_to_camera.html#adc21b54662c7247a3ab73394c8e663e7',1,'HapticFitToCamera']]],
  ['max_5fextents',['max_extents',['../class_haptic_plugin.html#a4e80228e53a8c02bdb26bb267c2ccf17',1,'HapticPlugin']]],
  ['minimumdepth',['MinimumDepth',['../class_haptic_fit_to_camera.html#a6acb6e225f7290188f47f57da8b7a91d',1,'HapticFitToCamera']]]
];
