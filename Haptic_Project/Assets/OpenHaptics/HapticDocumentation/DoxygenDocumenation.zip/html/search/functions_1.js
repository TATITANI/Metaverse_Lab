var searchData=
[
  ['effects_5fassigneffect',['effects_assignEffect',['../class_haptic_plugin.html#a4cd952c5e99b2be3794cf226851fd587',1,'HapticPlugin']]],
  ['effects_5fdeleteeffect',['effects_deleteEffect',['../class_haptic_plugin.html#ae77bc0f8a62b8c2ecf2b31934d7873ef',1,'HapticPlugin']]],
  ['effects_5fresetall',['effects_resetAll',['../class_haptic_plugin.html#aa3c9be4ab58b6aaf24c6150fc1ed25b0',1,'HapticPlugin']]],
  ['effects_5fsettings',['effects_settings',['../class_haptic_plugin.html#ae74d493b79a92b4509f06d1187e999f0',1,'HapticPlugin']]],
  ['effects_5fstarteffect',['effects_startEffect',['../class_haptic_plugin.html#ab159adc8595efdeae205c1cf9c06781d',1,'HapticPlugin']]],
  ['effects_5fstopeffect',['effects_stopEffect',['../class_haptic_plugin.html#ae30a67f5a05d1517b1098e4dd944b367',1,'HapticPlugin']]],
  ['effects_5ftype',['effects_type',['../class_haptic_plugin.html#af01904c85755ae6629f704918b04d707',1,'HapticPlugin']]]
];
