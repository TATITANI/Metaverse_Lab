var searchData=
[
  ['effecttype',['effectType',['../class_haptic_effect.html#a58bc6741c88d6483c1a7fd85e1f64126',1,'HapticEffect']]]
];
