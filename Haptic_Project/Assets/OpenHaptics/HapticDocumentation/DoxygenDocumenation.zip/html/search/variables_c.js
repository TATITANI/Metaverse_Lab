var searchData=
[
  ['usable_5fextents',['usable_extents',['../class_haptic_plugin.html#af9e9325c03bb46a8d21dd2a7dbeeb42d',1,'HapticPlugin']]]
];
