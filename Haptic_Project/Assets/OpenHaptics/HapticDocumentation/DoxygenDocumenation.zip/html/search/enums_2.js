var searchData=
[
  ['effect_5ftype',['EFFECT_TYPE',['../class_haptic_effect.html#a1564d4c9b76b33b1fa6cba145ff2165d',1,'HapticEffect']]]
];
